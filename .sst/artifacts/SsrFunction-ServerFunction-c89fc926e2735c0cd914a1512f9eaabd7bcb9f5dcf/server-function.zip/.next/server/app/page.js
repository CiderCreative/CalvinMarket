(() => {
var exports = {};
exports.id = 931;
exports.ids = [931];
exports.modules = {

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 98704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 97897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 56786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 5868:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/app-render");

/***/ }),

/***/ 41844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 96624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 75281:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/route-modules/route-module");

/***/ }),

/***/ 57085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 1830:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/get-img-props");

/***/ }),

/***/ 20199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 66864:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head");

/***/ }),

/***/ 39569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 52210:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config");

/***/ }),

/***/ 35359:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context");

/***/ }),

/***/ 17160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 30893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 12336:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url");

/***/ }),

/***/ 17887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 98735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 60120:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url");

/***/ }),

/***/ 68231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 54614:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix");

/***/ }),

/***/ 53750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 70982:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href");

/***/ }),

/***/ 79618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 78423:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils");

/***/ }),

/***/ 98658:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once");

/***/ }),

/***/ 71017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 57310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 6638:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   routeModule: () => (/* binding */ routeModule),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7262);
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(19513);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(31823);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(12502);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);
// @ts-ignore this need to be imported from next/dist to be external


const AppPageRouteModule = next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__.AppPageRouteModule;
// We inject the tree and pages here so that we can use them in the route
// module.
const tree = {
        children: [
        '',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 87395)), "/Users/blint/GitProj/calvinmarket/app/page.jsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 57481))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }]
      },
        {
        'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 18481)), "/Users/blint/GitProj/calvinmarket/app/layout.jsx"],
'not-found': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 95493, 23)), "next/dist/client/components/not-found-error"],
        metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 57481))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
      }
      ]
      }.children;
const pages = ["/Users/blint/GitProj/calvinmarket/app/page.jsx"];

// @ts-expect-error - replaced by webpack/turbopack loader

const __next_app_require__ = __webpack_require__
const __next_app_load_chunk__ = () => Promise.resolve()
const originalPathname = "/page";
const __next_app__ = {
    require: __next_app_require__,
    loadChunk: __next_app_load_chunk__
};

// Create and export the route module that will be consumed.
const routeModule = new AppPageRouteModule({
    definition: {
        kind: next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.APP_PAGE,
        page: "/page",
        pathname: "/",
        // The following aren't used in production.
        bundlePath: "",
        filename: "",
        appPaths: []
    },
    userland: {
        loaderTree: tree
    }
});

//# sourceMappingURL=app-page.js.map

/***/ }),

/***/ 67021:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 32278))

/***/ }),

/***/ 32278:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ page)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
;// CONCATENATED MODULE: ./components/Home/AccountIndication.jsx


const AccountIndication = ({ userName = "???????" })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        children: [
            "You are logged in as ",
            userName
        ]
    });
};
/* harmony default export */ const Home_AccountIndication = (AccountIndication);

;// CONCATENATED MODULE: ./components/Home/FilterButton.jsx


const FilterButton = ({ text, icon })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex items-center space-x-5 hover:cursor-pointer hover:opacity-70 transition-opacity duration-100",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: " bg-yellow rounded-full p-1",
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "aspect-square w-5 flex items-center justify-center",
                    children: icon
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                className: "text-sm",
                children: text
            })
        ]
    });
};
/* harmony default export */ const Home_FilterButton = (FilterButton);

;// CONCATENATED MODULE: ./constants/filterButtonInfo.jsx

const filterButtonInfo = [
    {
        text: "School Supplies",
        icon: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
            className: "aspect-square w-4 flex-shrink-0",
            "aria-hidden": "true",
            xmlns: "http://www.w3.org/2000/svg",
            fill: "none",
            viewBox: "0 0 21 21",
            children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                stroke: "currentColor",
                "stroke-linecap": "round",
                "stroke-linejoin": "round",
                "stroke-width": "2",
                d: "M7.418 17.861 1 20l2.139-6.418m4.279 4.279 10.7-10.7a3.027 3.027 0 0 0-2.14-5.165c-.802 0-1.571.319-2.139.886l-10.7 10.7m4.279 4.279-4.279-4.279m2.139 2.14 7.844-7.844m-1.426-2.853 4.279 4.279"
            })
        })
    },
    {
        text: "Books & Textbooks",
        icon: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
            className: "aspect-square w-4 flex-shrink-0",
            "aria-hidden": "true",
            xmlns: "http://www.w3.org/2000/svg",
            fill: "none",
            viewBox: "0 0 16 20",
            children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                stroke: "currentColor",
                "stroke-linecap": "round",
                "stroke-linejoin": "round",
                "stroke-width": "2",
                d: "M1 17V2a1 1 0 0 1 1-1h12a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H3a2 2 0 0 0-2 2Zm0 0a2 2 0 0 0 2 2h12M5 15V1m8 18v-4"
            })
        })
    },
    {
        text: "Furniture",
        icon: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
            className: "aspect-square w-4 flex-shrink-0",
            "aria-hidden": "true",
            xmlns: "http://www.w3.org/2000/svg",
            fill: "none",
            viewBox: "0 0 18 18",
            children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                stroke: "currentColor",
                "stroke-linecap": "round",
                "stroke-linejoin": "round",
                "stroke-width": "2",
                d: "M3 1h12M3 1v16M3 1H2m13 0v16m0-16h1m-1 16H3m12 0h2M3 17H1M6 4h1v1H6V4Zm5 0h1v1h-1V4ZM6 8h1v1H6V8Zm5 0h1v1h-1V8Zm-3 4h2a1 1 0 0 1 1 1v4H7v-4a1 1 0 0 1 1-1Z"
            })
        })
    },
    {
        text: "Electronics",
        icon: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
            className: "aspect-square w-4 flex-shrink-0",
            "aria-hidden": "true",
            xmlns: "http://www.w3.org/2000/svg",
            fill: "none",
            viewBox: "0 0 20 20",
            children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                stroke: "currentColor",
                "stroke-linecap": "round",
                "stroke-linejoin": "round",
                "stroke-width": "2",
                d: "M6 14H2a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1h16a1 1 0 0 1 1 1v1M5 19h5m-9-9h5m4-4h8a1 1 0 0 1 1 1v12H9V7a1 1 0 0 1 1-1Zm6 8a2 2 0 1 1-4 0 2 2 0 0 1 4 0Z"
            })
        })
    },
    {
        text: "Apparel",
        icon: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
            className: "aspect-square w-4 flex-shrink-0",
            "aria-hidden": "true",
            xmlns: "http://www.w3.org/2000/svg",
            fill: "none",
            viewBox: "0 0 14 18",
            children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                stroke: "currentColor",
                strokeLinecap: "round",
                strokeLinejoin: "round",
                strokeWidth: "2",
                d: "M7 8a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7Zm-2 3h4a4 4 0 0 1 4 4v2H1v-2a4 4 0 0 1 4-4Z"
            })
        })
    },
    {
        text: "New",
        icon: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
            className: "aspect-square w-4 flex-shrink-0",
            "aria-hidden": "true",
            xmlns: "http://www.w3.org/2000/svg",
            fill: "none",
            viewBox: "0 0 20 21",
            children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                stroke: "currentColor",
                strokeLinecap: "round",
                strokeLinejoin: "round",
                strokeWidth: "2",
                d: "M10 3.464V1.1m0 2.365a5.338 5.338 0 0 1 5.133 5.368v1.8c0 2.386 1.867 2.982 1.867 4.175C17 15.4 17 16 16.462 16H3.538C3 16 3 15.4 3 14.807c0-1.193 1.867-1.789 1.867-4.175v-1.8A5.338 5.338 0 0 1 10 3.464ZM4 3 3 2M2 7H1m15-4 1-1m1 5h1M6.54 16a3.48 3.48 0 0 0 6.92 0H6.54Z"
            })
        })
    },
    {
        text: "Free",
        icon: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
            className: "aspect-square w-4 flex-shrink-0",
            "aria-hidden": "true",
            xmlns: "http://www.w3.org/2000/svg",
            fill: "none",
            viewBox: "0 0 11 20",
            children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                stroke: "currentColor",
                strokeLinecap: "round",
                strokeLinejoin: "round",
                strokeWidth: "2",
                d: "M1.75 15.363a4.954 4.954 0 0 0 2.638 1.574c2.345.572 4.653-.434 5.155-2.247.502-1.813-1.313-3.79-3.657-4.364-2.344-.574-4.16-2.551-3.658-4.364.502-1.813 2.81-2.818 5.155-2.246A4.97 4.97 0 0 1 10 5.264M6 17.097v1.82m0-17.5v2.138"
            })
        })
    }
];

;// CONCATENATED MODULE: ./components/Home/FilterContainer.jsx




const FilterContainer = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "space-y-6 py-10 px-5",
        children: filterButtonInfo.map((filter, key)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: `h-[1px] w-5/6 rounded-full bg-opposite bg-opacity-50 m-auto ${filter.text === "School Supplies" || filter.text === "New" ? "" : "hidden"} `
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Home_FilterButton, {
                        text: filter.text,
                        icon: filter.icon
                    }, key)
                ]
            }))
    });
};
/* harmony default export */ const Home_FilterContainer = (FilterContainer);

;// CONCATENATED MODULE: ./components/Home/HighlightContainer.jsx


const HighlightContainer = ({ text })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        children: text
    });
};
/* harmony default export */ const Home_HighlightContainer = (HighlightContainer);

;// CONCATENATED MODULE: ./components/Home/ItemHighlight.jsx


const ItemHighlight = ()=>{
    return /*#__PURE__*/ _jsx("div", {
        children: "ItemHighlight"
    });
};
/* harmony default export */ const Home_ItemHighlight = ((/* unused pure expression or super */ null && (ItemHighlight)));

;// CONCATENATED MODULE: ./components/Home/ListingButtons.jsx



const ListingButtons = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex flex-col justify-center ml-[10%] w-[80%] space-y-3",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(Home_ButtonLink, {
                text: "Create a listing",
                link: "/EditListing",
                styles: "bg-[#20202030] font-semibold"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Home_ButtonLink, {
                text: "Edit listings",
                link: "/EditListing",
                styles: "border-2 border-opposite"
            })
        ]
    });
};
/* harmony default export */ const Home_ListingButtons = (ListingButtons);

;// CONCATENATED MODULE: ./components/Home/Searchbar.jsx


const Searchbar = ()=>{
    const searchIcon = /*#__PURE__*/ jsx_runtime_.jsx("svg", {
        class: "w-4 text-gray-800 dark:text-white",
        "aria-hidden": "true",
        xmlns: "http://www.w3.org/2000/svg",
        fill: "none",
        viewBox: "0 0 20 20",
        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
            stroke: "currentColor",
            "stroke-linecap": "round",
            "stroke-linejoin": "round",
            "stroke-width": "2",
            d: "m19 19-4-4m0-7A7 7 0 1 1 1 8a7 7 0 0 1 14 0Z"
        })
    });
    const placeholder = "Search";
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex items-center border-2 border-opposite rounded-xl w-[500px] px-5 py-2 space-x-3",
        children: [
            searchIcon,
            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                type: "text",
                autoComplete: "off",
                id: "name",
                placeholder: placeholder,
                className: "bg-transparent w-full border-transparent focus:outline-none focus:shadow-none"
            })
        ]
    });
};
/* harmony default export */ const Home_Searchbar = (Searchbar);

;// CONCATENATED MODULE: ./components/Home/Settings.jsx



const Settings = ()=>{
    const [settingsOpen, setSettingsOpen] = (0,react_.useState)(false);
    const [darkMode, setDarkMode] = (0,react_.useState)(false);
    const settingsIcon = /*#__PURE__*/ jsx_runtime_.jsx("svg", {
        class: "w-6 h-6 text-opposite hover:fill-[#cccccc] hover:cursor-pointer",
        "aria-hidden": "true",
        xmlns: "http://www.w3.org/2000/svg",
        fill: "none",
        viewBox: "0 0 20 20",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("g", {
            stroke: "currentColor",
            "stroke-linecap": "round",
            "stroke-linejoin": "round",
            "stroke-width": "1.5",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                    d: "M19 11V9a1 1 0 0 0-1-1h-.757l-.707-1.707.535-.536a1 1 0 0 0 0-1.414l-1.414-1.414a1 1 0 0 0-1.414 0l-.536.535L12 2.757V2a1 1 0 0 0-1-1H9a1 1 0 0 0-1 1v.757l-1.707.707-.536-.535a1 1 0 0 0-1.414 0L2.929 4.343a1 1 0 0 0 0 1.414l.536.536L2.757 8H2a1 1 0 0 0-1 1v2a1 1 0 0 0 1 1h.757l.707 1.707-.535.536a1 1 0 0 0 0 1.414l1.414 1.414a1 1 0 0 0 1.414 0l.536-.535L8 17.243V18a1 1 0 0 0 1 1h2a1 1 0 0 0 1-1v-.757l1.707-.708.536.536a1 1 0 0 0 1.414 0l1.414-1.414a1 1 0 0 0 0-1.414l-.535-.536.707-1.707H18a1 1 0 0 0 1-1Z"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                    d: "M10 13a3 3 0 1 0 0-6 3 3 0 0 0 0 6Z"
                })
            ]
        })
    });
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                onClick: ()=>{
                    setSettingsOpen(!settingsOpen);
                },
                children: settingsIcon
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: `absolute space-y-5 p-5 top-10 right-20 border-2 border-opposite rounded-xl ${settingsOpen ? "visible" : "hidden"}`,
                children: [
                    darkMode ? /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                        onClick: ()=>{
                            setDarkMode(!darkMode);
                        },
                        className: "w-6 h-6 text-opposite hover:cursor-pointer hover:scale-105",
                        "aria-hidden": "true",
                        xmlns: "http://www.w3.org/2000/svg",
                        fill: "none",
                        viewBox: "0 0 18 20",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                            stroke: "currentColor",
                            "stroke-linecap": "round",
                            "stroke-linejoin": "round",
                            "stroke-width": "2",
                            d: "M8.509 5.75c0-1.493.394-2.96 1.144-4.25h-.081a8.5 8.5 0 1 0 7.356 12.746A8.5 8.5 0 0 1 8.509 5.75Z"
                        })
                    }) : /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                        onClick: ()=>{
                            setDarkMode(!darkMode);
                        },
                        className: "w-6 h-6 text-opposite hover:cursor-pointer hover:scale-105",
                        "aria-hidden": "true",
                        xmlns: "http://www.w3.org/2000/svg",
                        fill: "none",
                        viewBox: "0 0 20 20",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                            stroke: "currentColor",
                            "stroke-linecap": "round",
                            "stroke-linejoin": "round",
                            "stroke-width": "2",
                            d: "M10 3V1m0 18v-2M5.05 5.05 3.636 3.636m12.728 12.728L14.95 14.95M3 10H1m18 0h-2M5.05 14.95l-1.414 1.414M16.364 3.636 14.95 5.05M14 10a4 4 0 1 1-8 0 4 4 0 0 1 8 0Z"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                        className: "inline-block bg-maroon text-light px-5 py-2 rounded-md hover:cursor-pointer hover:scale-[102%] transition-transform duration-100",
                        children: "Log out"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {})
                ]
            })
        ]
    });
};
/* harmony default export */ const Home_Settings = (Settings);

;// CONCATENATED MODULE: ./public/wayfinder.svg
/* harmony default export */ const wayfinder = ({"src":"/_next/static/media/wayfinder.0a481dd9.svg","height":795,"width":600,"blurWidth":0,"blurHeight":0});
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(52451);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./components/Global/Logo.jsx



const Logo = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex flex-col items-center pt-5 pb-10",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                src: wayfinder,
                className: "aspect-square w-8",
                alt: "Calvin University Wayfinder Logo"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                className: "text-2xl font-semibold",
                children: "Calvin Market"
            })
        ]
    });
};
/* harmony default export */ const Global_Logo = (Logo);

;// CONCATENATED MODULE: ./components/Global/index.js



;// CONCATENATED MODULE: ./components/Home/HomeSidebar.jsx
/* __next_internal_client_entry_do_not_use__ default auto */ 


const HomeSidebar = ({ sidebarClosed, setSidebarClosed })=>{
    const arrow = /*#__PURE__*/ jsx_runtime_.jsx("svg", {
        className: `w-5 text-opposite flex-shrink-0 ${sidebarClosed ? "rotate-0" : "rotate-180"}`,
        "aria-hidden": "true",
        xmlns: "http://www.w3.org/2000/svg",
        fill: "none",
        viewBox: "0 0 12 10",
        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
            stroke: "currentColor",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "2",
            d: "m7 9 4-4-4-4M1 9l4-4-4-4"
        })
    });
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: `fixed top-0 left-0 bg-primary w-[300px] h-full ${sidebarClosed ? "w-[50px]" : ""} transition-all duration-300 overflow-hidden`,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "flex justify-end m-3 hover:cursor-pointer",
                onClick: ()=>{
                    setSidebarClosed(!sidebarClosed);
                },
                children: arrow
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: `${sidebarClosed ? "hidden" : ""}`,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(Global_Logo, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(Home_ListingButtons, {}),
                    "    ",
                    /*#__PURE__*/ jsx_runtime_.jsx(Home_FilterContainer, {}),
                    "   "
                ]
            })
        ]
    });
};
/* harmony default export */ const Home_HomeSidebar = (HomeSidebar);

// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(11440);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./components/Home/ButtonLink.jsx



const ButtonLink = ({ text, link, styles })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("button", {
        className: `py-2 rounded-xl hover:scale-[103%] transition-all duration-100 text-sm ${styles}`,
        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
            href: link,
            children: text
        })
    });
};
/* harmony default export */ const Home_ButtonLink = (ButtonLink);

;// CONCATENATED MODULE: ./components/Home/index.js












;// CONCATENATED MODULE: ./app/page.jsx
/* __next_internal_client_entry_do_not_use__ default auto */ 


function Home({ signOut, user }) {
    const [sidebarClosed, setSidebarClosed] = (0,react_.useState)(false);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: `transition-all duration-300 pl-[300px] ${sidebarClosed ? "pl-[50px]" : "pl-[300px]"}`,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(Home_HomeSidebar, {
                sidebarClosed: sidebarClosed,
                setSidebarClosed: setSidebarClosed
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex justify-between mx-5 mt-2",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(Home_Searchbar, {}),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex space-x-5",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(Home_AccountIndication, {}),
                            /*#__PURE__*/ jsx_runtime_.jsx(Home_Settings, {})
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Home_HighlightContainer, {
                text: "Top 5"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Home_HighlightContainer, {
                text: "Newly Added"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Home_HighlightContainer, {
                text: "Textbooks"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Home_HighlightContainer, {
                text: "Free Items"
            })
        ]
    });
}
/* harmony default export */ const page = (Home);


/***/ }),

/***/ 87395:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $$typeof: () => (/* binding */ $$typeof),
/* harmony export */   __esModule: () => (/* binding */ __esModule),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(61363);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`/Users/blint/GitProj/calvinmarket/app/page.jsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [587,609,775,86], () => (__webpack_exec__(6638)));
module.exports = __webpack_exports__;

})();